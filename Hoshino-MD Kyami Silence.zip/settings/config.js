//SCRIPT BY KYAMI SILENCE 
//SCRIPT INI FREE JADI JANGAN DI JUAL PUQI 
// YT : @SlncKyami


const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "6285167249152" //ganti aja
global.nama = "ᴋʏᴀᴍɪ sɪʟᴇɴᴄᴇ" //ganti aja
global.namaowner = "sʟɴᴄ-ᴋʏᴀᴍɪ" // Ganti aja
global.namaBot = "ᴛᴀᴋᴀɴᴀsʜɪ ʜᴏsʜɪɴᴏ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ" // Ganti aja
global.ch = 'https://whatsapp.com/channel/0029Vb1KZGfD38COhcA6MQ3u' // Ganti aja
global.ownername = "sʟɴᴄ-ᴋʏᴀᴍɪ" // Ganti aja
global.botname = "ᴛᴀᴋᴀɴᴀsʜɪ ʜᴏsʜɪɴᴏ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ" // Ganti aja
global.status = true 
global.foother = "©ᴛᴀᴋᴀɴᴀsʜɪ ʜᴏsʜɪɴᴏ" // Ganti aja
global.namach = 'ᴋʏᴀᴍɪ ɴᴇᴠᴇʀ ᴄʀʏ' // Ganti aja
global.idch = '120363366790950043@newsletter' // diemin kalau gda
global.namafile = 'ᴋʏᴀᴍɪ ɢᴀᴍᴛᴇɴɢ' // Ganti aja
global.yt = 'https://youtube.com/@slnckyami' // Ganti aja
global.themeemoji = '🌸' // Ganti aja
global.packname = "sᴛɪᴄᴋᴇʀ ʙʏ" // Ganti aja
global.author = "\n\n\n\n\nᴄʀᴇᴀᴛᴇ ʙʏ ᴛᴀᴋᴀɴᴀsʜɪ ʜᴏsʜɪɴᴏ\nʏᴛ : sʟɴᴄᴋʏᴀᴍɪ" // Ganti aja
global.creator = "6285167249152@s.whatsapp.net" // Ganti aja
global.welcome = false
global.autoswview = true //auto status/story view
global.delayPushkontak = 7500
//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "081250431837" // Ganti aja
global.ovo = "Tidak Tersedia" // Ganti aja
global.qris = "https://img86.pixhost.to/images/414/561641458_slnckyami.jpg" // Ganti aja
//====== [ THEME URL & URL ] ========//
global.thumb = fs.readFileSync('./kyami.jpg'); // Buffer Image
global.thumbfurina = 'https://files.catbox.moe/g6cbbn.jpg'
global.thumbnail = 'https://files.catbox.moe/g6cbbn.jpg' // Ganti aja
global.reply = 'https://files.catbox.moe/g6cbbn.jpg' // Ganti aja
global.Url = '-' // Ganti aja
global.logodana = "https://img100.pixhost.to/images/667/540082364_skyzopedia.jpg",  // Ganti aja
global.logoovo = "https://img100.pixhost.to/images/667/540082774_skyzopedia.jpg",  // Ganti aja
//===================== Setting Apikey V1 =========================//
global.domain = 'https://'
global.apikey = 'plta'
global.capikey = 'pltc'
//===================== Setting Apikey V2 =========================//
global.domain2 = "https://hanzo-hosting-publik.pterodactyl-vvip.my.id"
global.apikey2 = "ptla_ZbBr2eO8jepwKpJ8zNMvHAyx6mTxMUeD3IND7QMzLRO"
global.capikey2 = "ptlc_73mP8JX8pOoxKi7h55obFyOUKmG3e4GTDhuc8Xtq8kL"
//===================== Setting Apikey V3 =========================//
global.domain3 = "https://kenzstore-mujib.zackyoffc.xyz"
global.apikey3 = "ptla_h51ID3CRoGZxwAMA2OAQXSDZ5xUoGGXSBICCEICV8dM"
global.capikey3 = "ptlc_9H4b9yPFtunO8K17xcZzn1wHThwvoO9oyEW3LwIJN4I"
//===================== BIARIN!!!! =========================//
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

// jpm ch isi id nya
global.jpmch1 = "120363366452398075@newsletter"
global.jpmch2 = ""
global.jpmch3 = ""
global.jpmch4 = ""
global.jpmch5 = ""
global.jpmch6 = ""
global.jpmch7 = ""
global.jpmch8 = ""
global.jpmch9 = ""
global.jpmch10 = ""
global.jpmch11 = ""
global.jpmch12 = ""
global.jpmch13 = ""
global.jpmch14 = ""
global.jpmch15 = ""
global.jpmch16 = ""
global.jpmch17 = ""
global.jpmch18 = ""
global.jpmch19 = ""
global.jpmch20 = ""
global.jpmch21 = ""
global.jpmch22 = ""
global.jpmch23 = ""
global.jpmch24 = ""
global.jpmch25 = ""
global.jpmch26 = ""
global.jpmch27 = ""
global.jpmch28 = ""
global.jpmch29 = ""
global.jpmch30 = ""
global.jpmch31 = ""
global.jpmch32 = ""
global.jpmch33 = ""
global.jpmch34 = ""
global.jpmch35 = ""
global.jpmch36 = ""
global.jpmch37 = ""
global.jpmch38 = ""
global.jpmch39 = ""
global.jpmch40 = ""
global.jpmch41 = ""
global.jpmch42 = ""
global.jpmch43 = ""
global.jpmch44 = ""
global.jpmch45 = ""
global.jpmch46 = ""
global.jpmch47 = ""
global.jpmch48 = ""
global.jpmch49 = ""
global.jpmch50 = ""
global.jpmch51 = ""
global.jpmch52 = ""
global.jpmch53 = ""
global.jpmch54 = ""
global.jpmch55 = ""
global.jpmch56 = ""
global.jpmch57 = ""
global.jpmch58 = ""
global.jpmch59 = ""
global.jpmch60 = ""
global.jpmch61 = ""
global.jpmch62 = ""
global.jpmch63 = ""
global.jpmch64 = ""
global.jpmch65 = ""
global.jpmch66 = ""
global.jpmch67 = ""
global.jpmch68 = ""
global.jpmch69 = ""
global.jpmch70 = ""
global.jpmch71 = ""
global.jpmch72 = ""
global.jpmch73 = ""
global.jpmch74 = ""
global.jpmch75 = ""
global.jpmch76 = ""
global.jpmch77 = ""
global.jpmch78 = ""
global.jpmch79 = ""
global.jpmch80 = ""
global.jpmch81 = ""
global.jpmch82 = ""
global.jpmch83 = ""
global.jpmch84 = ""
global.jpmch85 = ""
global.jpmch86 = ""
global.jpmch87 = ""
global.jpmch88 = ""
global.jpmch89 = ""
global.jpmch90 = ""
global.jpmch91 = ""
global.jpmch92 = ""
global.jpmch93 = ""
global.jpmch94 = ""
global.jpmch95 = ""
global.jpmch96 = ""
global.jpmch97 = ""
global.jpmch98 = ""
global.jpmch99 = ""
global.jpmch100 = ""
global.jpmch101 = ""
global.jpmch102 = ""
global.jpmch103 = ""
global.jpmch104 = ""
global.jpmch105 = ""
global.jpmch106 = ""
global.jpmch107 = ""
global.jpmch108 = ""
global.jpmch109 = ""
global.jpmch110 = ""
global.jpmch111 = ""
global.jpmch112 = ""
global.jpmch113 = ""
global.jpmch114 = ""
global.jpmch115 = ""
global.jpmch116 = ""
global.jpmch117 = ""
global.jpmch118 = ""
global.jpmch119 = ""
global.jpmch120 = ""
global.jpmch121 = ""
global.jpmch122 = ""
global.jpmch123 = ""
global.jpmch124 = ""
global.jpmch125 = ""
global.jpmch126 = ""
global.jpmch127 = ""
global.jpmch128 = ""
global.jpmch129 = ""
global.jpmch130 = ""
global.jpmch131 = ""
global.jpmch132 = ""
global.jpmch133 = ""
global.jpmch134 = ""
global.jpmch135 = ""
global.jpmch136 = ""
global.jpmch137 = ""
global.jpmch138 = ""
global.jpmch139 = ""
global.jpmch140 = ""
global.jpmch141 = ""
global.jpmch142 = ""
global.jpmch143 = ""
global.jpmch144 = ""
global.jpmch145 = ""
global.jpmch146 = ""
global.jpmch147 = ""
global.jpmch148 = ""
global.jpmch149 = ""
global.jpmch150 = ""
//~~~~~~~~~ Settings reply ~~~~~~~~~//
global.mess = {
    owner: "𝙏𝙝𝙞𝙨 𝙄𝙨 𝙁𝙤𝙧 𝙊𝙬𝙣𝙚𝙧, 𝙉𝙤𝙩 𝙁𝙤𝙧 𝙔𝙤𝙪 ´◡`",
    prem: "𝙏𝙝𝙞𝙨 𝙄𝙨 𝙁𝙤𝙧 𝙋𝙧𝙚𝙢𝙞𝙪𝙢, 𝙉𝙤𝙩 𝙁𝙤𝙧 𝙔𝙤𝙪 ´◡`",
    group: "𝙏𝙝𝙞𝙨 𝙄𝙨 𝙁𝙤𝙧 𝙂𝙧𝙤𝙪𝙥 𝙊𝙣𝙡𝙮 ´◡`",
    private: "𝙊𝙣𝙡𝙮 𝙋𝙧𝙞𝙫𝙖𝙩𝙚 𝘾𝙝𝙖𝙩 𝙎𝙞𝙧 ´◡`"
}


global.packname = 'ᴛᴀᴋᴀɴᴀsʜɪ ʜᴏsʜɪɴᴏ' // Ganti aja
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n@Kyami Silence' // Ganti aja
//~~~~~~~~~~~ DIEMIN ~~~~~~~~~~//
global.pairing = "" // Jangan Di Apa Apain
global.qrcode = "120363366790950043@newsletter" // Jangan Di Apa Apain

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
